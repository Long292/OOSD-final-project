package com.example.hospitalvisit.Patient;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.hospitalvisit.R;



public class PatientHomepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_homepage);
    }
}